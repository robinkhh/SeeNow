<!-- https://github.com/wenzhixin/bootstrap-table/blob/develop/CONTRIBUTING.md#bug-reports -->


Short and descriptive example bug report title

A summary of the issue and the browser/OS environment in which it occurs. If suitable, include the steps required to reproduce the bug.

This is the first step
This is the second step
Further steps, etc.

[jsfiddle]() - a link to the reduced test case([fiddle template](https://github.com/wenzhixin/bootstrap-table/issues/1765)).

Any other information you want to share that is relevant to the issue being reported. This might include the lines of code that you have identified as causing the bug, and potential solutions (and your opinions on their merits).

<!-- Love bootstrap-table? Please consider supporting our collective:
👉  https://opencollective.com/bootstrap-table/donate -->